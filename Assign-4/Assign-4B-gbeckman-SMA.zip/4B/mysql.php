<?php
//skhpa2@yahoo.com
$resid=MySQLi_Connect('localhost','gbeckman','gray','gbeckman');
					if(MySQLi_Connect_Errno()) {
						echo "<tr align='center'> <td colspan='5'> Failed to connect to MySQL </td> </tr>";
					}
					else {
					}
